module.exports=[47524,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_liff-id_route_actions_b0b87b8d.js.map