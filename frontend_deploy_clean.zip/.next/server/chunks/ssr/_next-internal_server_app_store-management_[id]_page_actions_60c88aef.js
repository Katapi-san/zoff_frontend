module.exports=[39713,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_store-management_%5Bid%5D_page_actions_60c88aef.js.map