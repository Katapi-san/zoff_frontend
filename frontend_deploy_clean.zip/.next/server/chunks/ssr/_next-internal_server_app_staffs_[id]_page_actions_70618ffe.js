module.exports=[48217,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_staffs_%5Bid%5D_page_actions_70618ffe.js.map