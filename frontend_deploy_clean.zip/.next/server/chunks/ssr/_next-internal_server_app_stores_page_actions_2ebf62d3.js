module.exports=[66977,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_stores_page_actions_2ebf62d3.js.map