module.exports=[12030,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_stores_%5Bid%5D_queue_page_actions_ef3aaca1.js.map