module.exports=[44641,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_stores_%5Bid%5D_page_actions_aeb8f8e5.js.map