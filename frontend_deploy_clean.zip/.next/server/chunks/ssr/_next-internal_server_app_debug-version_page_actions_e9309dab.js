module.exports=[64576,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_debug-version_page_actions_e9309dab.js.map