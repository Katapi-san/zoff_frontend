module.exports=[49354,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reservation_staff_%5Bid%5D_page_actions_4d0da0e0.js.map