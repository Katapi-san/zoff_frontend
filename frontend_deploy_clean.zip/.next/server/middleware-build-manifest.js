globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/11c03e5916e082fb.js",
    "static/chunks/112f346e31f991df.js",
    "static/chunks/1b6bea81529e7d4f.js",
    "static/chunks/62efa5d0e24f3972.js",
    "static/chunks/3ee8b03b18b9c113.js",
    "static/chunks/turbopack-da5cf063dd1c4fac.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];