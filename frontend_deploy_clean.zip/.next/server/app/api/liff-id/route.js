var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/liff-id/route.js")
R.c("server/chunks/[root-of-the-server]__7a21fc67._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_liff-id_route_actions_b0b87b8d.js")
R.m(12875)
module.exports=R.m(12875).exports
